//
//  sampleffi.m
//  SampleFFI
//
//  
//  Author : Kony Solutions 
//

#import "sampleffi.h"
#import "stdlib.h"
#import "lglobals.h"
#import "SampleIphoneScreen.h"

@implementation sampleffi

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}


+ (NSString *) memberRegister:(NSNumber *) experience withName:(NSString *) name andBool:(BOOL) isMarriedBool andprogLang:(NSArray *) progLang
{
    NSString * progLangString = [ progLang componentsJoinedByString:@","];
    NSString * isMarriedString;
    if(isMarriedBool) {
        isMarriedString = @"YES";
    }else {
        isMarriedString = @"NO";
    }
    int randomNumber = arc4random_uniform(1000);
    NSString * resultString = [@"You have been registered with:<br>Resgistration Number: " stringByAppendingString:[NSString stringWithFormat:@"%d",randomNumber] ];
    resultString = [resultString stringByAppendingString:[@"<br>Name: " stringByAppendingString:name]];
    resultString = [resultString stringByAppendingString:[@"<br>Experience: " stringByAppendingString:[experience stringValue]]];
    resultString = [resultString stringByAppendingString:[@"<br>Married: " stringByAppendingString:isMarriedString]];
    resultString = [resultString stringByAppendingString:[@"<br>Programming Languages Known: " stringByAppendingString:progLangString]];
    return resultString;
}

+ (void) asyncmemberRegister:(NSNumber *) experience withName:(NSString *) name andBool:(BOOL) isMarriedBool andprogLang:(NSArray *) progLang andCallback:(LuaClosure *) callback
{
    NSString * progLangString = [ progLang componentsJoinedByString:@","];
    NSString * isMarriedString;
    NSMutableArray *valueOfDic;
    if(isMarriedBool) {
        isMarriedString = @"YES";
    }else {
        isMarriedString = @"NO";
    }
    int randomNumber = arc4random_uniform(1000);    
	NSMutableDictionary * infoTable = [NSMutableDictionary dictionary];
    [infoTable setObject:[NSNumber numberWithInt:randomNumber] forKey:@"regNo"];
    [infoTable setObject:experience forKey:@"experience"];
    [infoTable setObject:name forKey:@"Name"];
    [infoTable setObject:isMarriedString forKey:@"isMarried"];
    [infoTable setObject:progLangString forKey:@"progLang"];
    valueOfDic = [[NSMutableArray alloc] initWithObjects:infoTable, nil];
	doExecuteClosure(callback,valueOfDic);
}

+ (void) onJSClickActivity
{
    UIWindow * currentwindow = [[UIApplication sharedApplication] keyWindow];
    SampleIphoneScreen* currentview = [[SampleIphoneScreen alloc] initWithNibName:nil bundle:nil];
    [currentwindow addSubview:currentview.view];
}

@end
