//
//  sampleffi.h
//  SampleFFI
//
//  Created by Platform QA on 11/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LuaTable.h"
#import "LuaClosure.h"

@interface sampleffi : NSObject

+ (NSString *) memberRegister:(NSNumber *) experience withName:(NSString *) name andBool:(BOOL) isMarriedBool andprogLang:(NSArray *) progLang;
+ (void) asyncmemberRegister:(NSNumber *) experience withName:(NSString *) name andBool:(BOOL) isMarriedBool andprogLang:(NSArray *) progLang andCallback:(LuaClosure *) callback;
+ (void) onLuaClickActivity;

@end
