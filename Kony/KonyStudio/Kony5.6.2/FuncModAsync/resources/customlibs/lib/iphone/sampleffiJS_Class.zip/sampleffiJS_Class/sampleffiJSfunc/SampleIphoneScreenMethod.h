//
//  SampleIphoneScreen.h
//  VM
//
//  Created by Platform QA on 12/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SampleIphoneScreenMethod : UIViewController

- (void)onButtonClickRemoveView: (id) sender;

@end
