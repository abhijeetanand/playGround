//
//  SampleIphoneScreen.h
//  VM

//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SampleIphoneScreen : UIViewController

- (void)onButtonClickRemoveView: (id) sender;

@end
